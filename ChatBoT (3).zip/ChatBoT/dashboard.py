from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, abort, current_app
from flask_login import login_required, current_user
from chat_logic import get_response
from functools import wraps

dashboard = Blueprint('dashboard', __name__)

# Admin-required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin:
            flash('You need to be an admin to access this page', 'danger')
            return redirect(url_for('dashboard.home'))
        return f(*args, **kwargs)
    return decorated_function

@dashboard.route('/')
@login_required
def home():
    """Student dashboard home page"""
    return render_template('dashboard.html', user=current_user)

@dashboard.route('/profile')
@login_required
def profile():
    """Student profile page"""
    return render_template('profile.html', user=current_user)

@dashboard.route('/chatbot')
@login_required
def chatbot():
    """Chatbot page - accessible to all logged-in users (students and admins)"""
    return render_template('chat.html', user=current_user)

@dashboard.route('/get_response')
@login_required
def get_bot_response():
    """API endpoint to get bot response - only for authenticated users"""
    user_input = request.args.get('msg')
    
    if not user_input:
        return "Please enter a valid message."
    
    connection = current_app.get_db_connection()
    if connection:
        try:
            bot_reply = get_response(user_input, connection)
            return bot_reply
        except Exception as e:
            print("Processing Error:", e)
            return "Something went wrong while processing your message."
        finally:
            connection.close()
    else:
        return "Unable to connect to the database. Please try again later."

@dashboard.route('/admin')
@login_required
@admin_required
def admin():
    """Admin panel - only accessible to users with admin role"""
    connection = current_app.get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM users ORDER BY id")
            users = cursor.fetchall()
            return render_template('admin.html', user=current_user, users=users)
        except Exception as e:
            flash(f'Error retrieving users: {e}', 'danger')
            return redirect(url_for('dashboard.home'))
        finally:
            connection.close()
    else:
        flash('Unable to connect to the database', 'danger')
        return redirect(url_for('dashboard.home'))

@dashboard.route('/admin/make_admin/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def make_admin(user_id):
    """Toggle admin status for a user"""
    if user_id == current_user.id:
        flash('You cannot change your own admin status', 'warning')
        return redirect(url_for('dashboard.admin'))
    
    connection = current_app.get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            # Get current admin status
            cursor.execute("SELECT is_admin FROM users WHERE id = ?", (user_id,))
            user_data = cursor.fetchone()
            if not user_data:
                flash('User not found', 'danger')
                return redirect(url_for('dashboard.admin'))
            
            # Toggle admin status
            new_status = 0 if user_data[0] else 1
            cursor.execute("UPDATE users SET is_admin = ? WHERE id = ?", (new_status, user_id))
            connection.commit()
            flash('User admin status updated successfully', 'success')
        except Exception as e:
            flash(f'Error updating user: {e}', 'danger')
        finally:
            connection.close()
    
    return redirect(url_for('dashboard.admin'))
