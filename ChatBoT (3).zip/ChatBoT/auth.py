from flask import Blueprint, render_template, redirect, url_for, flash, request, session, current_app
from flask_login import login_user, logout_user, login_required, current_user
from models import User

auth = Blueprint('auth', __name__)

def get_user_by_username(username, connection):
    """Retrieve user from database by username"""
    cursor = connection.cursor()
    cursor.execute("SELECT id, username, email, password_hash, student_id, name, is_admin FROM users WHERE username = ?", (username,))
    user_data = cursor.fetchone()
    
    if user_data:
        return User(
            id=user_data[0],
            username=user_data[1],
            email=user_data[2],
            password_hash=user_data[3],
            student_id=user_data[4],
            name=user_data[5],
            is_admin=user_data[6] if len(user_data) > 6 else False
        )
    return None

def get_user_by_id(user_id, connection):
    """Retrieve user from database by ID"""
    cursor = connection.cursor()
    cursor.execute("SELECT id, username, email, password_hash, student_id, name, is_admin FROM users WHERE id = ?", (user_id,))
    user_data = cursor.fetchone()
    
    if user_data:
        return User(
            id=user_data[0],
            username=user_data[1],
            email=user_data[2],
            password_hash=user_data[3],
            student_id=user_data[4],
            name=user_data[5],
            is_admin=user_data[6] if len(user_data) > 6 else False
        )
    return None

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Get db connection from app context
        connection = current_app.get_db_connection()
        
        if connection:
            try:
                user = get_user_by_username(username, connection)
                
                if user and User.check_password(user.password_hash, password):
                    login_user(user)
                    session['user_id'] = user.id
                    flash('Login successful!', 'success')
                    return redirect(url_for('dashboard.home'))
                else:
                    flash('Invalid username or password!', 'danger')
            finally:
                connection.close()
        else:
            flash('Database connection error!', 'danger')
    
    return render_template('login.html')

@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        student_id = request.form.get('student_id')
        name = request.form.get('name')
        
        # Form validation
        if not username or not email or not password or not confirm_password:
            flash('All fields are required!', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return render_template('register.html')
        
        # Get db connection
        connection = current_app.get_db_connection()
        
        if connection:
            try:
                cursor = connection.cursor()
                
                # Check if username already exists
                cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
                if cursor.fetchone():
                    flash('Username already exists!', 'danger')
                    return render_template('register.html')
                
                # Check if email already exists
                cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
                if cursor.fetchone():
                    flash('Email already in use!', 'danger')
                    return render_template('register.html')
                
                # Create new user
                user_data = User.create_user(username, email, password, student_id, name)
                
                # Check if this is the first user (make them admin)
                cursor.execute("SELECT COUNT(*) FROM users")
                is_first_user = cursor.fetchone()[0] == 0
                
                # Set admin flag if first user or if username contains 'admin'
                is_admin = is_first_user or 'admin' in username.lower()
                user_data = User.create_user(username, email, password, student_id, name, is_admin)
                
                # Insert user into database
                sql = """
                INSERT INTO users (username, email, password_hash, student_id, name, is_admin) 
                VALUES (?, ?, ?, ?, ?, ?)
                """
                cursor.execute(sql, (
                    user_data['username'],
                    user_data['email'],
                    user_data['password_hash'],
                    user_data['student_id'],
                    user_data['name'],
                    user_data['is_admin']
                ))
                connection.commit()
                
                flash('Registration successful! Please login.', 'success')
                return redirect(url_for('auth.login'))
            except Exception as e:
                connection.rollback()
                flash(f'An error occurred: {str(e)}', 'danger')
            finally:
                cursor.close()
                connection.close()
        else:
            flash('Database connection error!', 'danger')
    
    return render_template('register.html')

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    if 'user_id' in session:
        session.pop('user_id')
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))
