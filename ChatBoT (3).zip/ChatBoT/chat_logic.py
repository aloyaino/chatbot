import re
import random

# Preprocessing to clean user input
def preprocess(user_input):
    user_input = user_input.lower()
    user_input = re.sub(r'[^\w\s]', '', user_input)
    return user_input


# Helper function to add variety to bot responses
def get_greeting():
    greetings = [
        "Hi there!",
        "Hello!",
        "Greetings!",
        "Welcome!",
    ]
    return random.choice(greetings)


# Add personality and variety to responses
def add_personality(response):
    positive_endings = [
        "Hope that helps!",
        "Let me know if you need more information.",
        "Is there anything else you'd like to know?",
        "Feel free to ask if you have more questions.",
    ]
    
    if len(response) > 20 and random.random() < 0.7:  # 70% chance to add personality
        return f"{response} {random.choice(positive_endings)}"
    return response


# Main chatbot response logic
def get_response(user_input, connection):
    cursor = connection.cursor()
    user_input = preprocess(user_input)
    
    # Check for greetings
    if re.search(r'\b(hi|hello|hey|greetings)\b', user_input):
        return f"{get_greeting()} How can I assist you with ESUI university information today?"

    # Check for thanks
    if re.search(r'\b(thanks|thank you|thank)\b', user_input):
        return "You're welcome! I'm happy to help with any other questions you might have."
        
    # Check for bot identity questions
    if re.search(r'\b(who are you|what are you|your name)\b', user_input):
        return "I'm the ESUI University Assistant, designed to help students with information about courses, fees, admissions, and campus life."

    ### COURSE FEES ###
    if "fee" in user_input or "school fees" in user_input or "tuition" in user_input:
        try:
            course_match = re.search(r'for (.+)', user_input)
            if course_match:
                course_name = course_match.group(1).strip()
                sql = "SELECT fee_local, fee_foreign FROM course_fees WHERE course_name LIKE ?"
                cursor.execute(sql, (f"%{course_name}%",))
                result = cursor.fetchone()
                if result:
                    return f"The tuition fee for {course_name.title()} is ₦{result[0]:,} (Local) and ${result[1]:,} (Foreign students)."

                return "Sorry, I couldn't find fee information for that course."

            # General fee list if no specific course mentioned
            sql = "SELECT course_name, fee_local FROM course_fees"
            cursor.execute(sql)
            results = cursor.fetchall()
            if results:
                fee_info = "Here are some course fees:\n"
                for course, fee_local in results:
                    fee_info += f"- {course.title()}: ₦{fee_local:,}\n"
                return fee_info
            else:
                return "I don't have fee information at the moment."
        except Exception as e:
            print("Database error:", e)
            return "There was an issue retrieving fee information."

    ### CUT-OFF MARKS ###
    elif "cut off" in user_input or "cut-off" in user_input:
        try:
            # For SQLite demo, we'll create a simple response since we don't have the cut_off_marks table yet
            return "Cut-off marks information is currently being updated. Please check back later."
        except Exception as e:
            print("Database error:", e)
            return "There was an issue retrieving cut-off mark information."

    ### ADMISSION INFO ###
    elif "admission" in user_input or "apply" in user_input:
        try:
            for keyword, field in [
                ("acceptance", "acceptance fee"),
                ("application", "application_fees"),
                ("cut off policy", "cut_off_policy"),
                ("direct entry", "direct_entry"),
                ("transfer", "transfer"),
                ("how to apply", "how_to_apply"),
                ("screening", "screening_procedure"),
                ("fee payment", "fee payment"),
                ("process", "admission process"),
            ]:
                if keyword in user_input:
                    # For SQLite demo, we'll return a simple response
                    return f"Information about {field} is available on the university website."

            # For SQLite demo, return a generic admission response
            return "For admission into our university, you need to meet the minimum cut-off mark for your desired program and submit an application through our online portal. Registration is currently open for the 2025/2026 academic session."
        except Exception as e:
            print("Database error:", e)
            return "There was an issue retrieving admission information."

    ### HOSTEL INFO ###
    elif "hostel" in user_input or "accommodation" in user_input:
        try:
            # For SQLite demo, return static hostel information
            return "The university offers various hostel accommodations for both male and female students. Prices range from ₦50,000 to ₦150,000 per session depending on the hostel type. All hostels include basic amenities such as water, electricity, and security."
        except Exception as e:
            print("Database error:", e)
            return "There was an issue retrieving hostel information."

    ### COURSE REGISTRATION ###
    elif "register" in user_input or "course" in user_input:
        try:
            # For SQLite demo, return static course registration information
            return "Course registration is done online through the student portal. Registration for returning students opens two weeks before the start of each semester. New students will receive registration instructions upon admission."
        except Exception as e:
            print("Database error:", e)
            return "There was an issue retrieving course registration information."

    ### CAMPUS SERVICES ###
    elif "library" in user_input or "medical" in user_input or "ict" in user_input or "cafeteria" in user_input or "service" in user_input:
        try:
            # For SQLite demo, return static campus services information
            return "Campus services include the main library (open 8am-10pm), ICT center, medical center (24/7), cafeteria, sports facilities, and student support services."
        except Exception as e:
            print("Database error:", e)
            return "There was an issue retrieving campus service information."

    ### GENERAL INQUIRIES ###
    # Academic calendar related queries
    elif re.search(r'\b(semester|calendar|academic year|holiday|break|vacation)\b', user_input):
        try:
            return add_personality("The academic year consists of two semesters. The first semester typically runs from September to January, and the second semester from February to June. Major breaks include Christmas holiday (late December), Easter break (varies), and summer vacation (July-August).")
        except Exception as e:
            print("Error:", e)
            return "I don't have the academic calendar information at the moment."
            
    # Exam related queries
    elif re.search(r'\b(exam|examination|test|assessment)\b', user_input):
        try:
            return add_personality("Examinations are conducted at the end of each semester. Continuous assessments typically account for 30% of your final grade, while the end-of-semester examination accounts for 70%. Please check your department's specific grading policy for more details.")
        except Exception as e:
            print("Error:", e)
            return "I don't have specific examination information at the moment."
    
    # Contact information
    elif re.search(r'\b(contact|phone|email|reach|office|hours)\b', user_input):
        try:
            return add_personality("You can contact the university through email at info@esui.edu, or by phone at +234-123-4567. The administrative office is open Monday to Friday, 9am to 4pm. Each department also has specific contact information available on the university website.")
        except Exception as e:
            print("Error:", e)
            return "I don't have the contact information at the moment."
    
    # Fallback response
    else:
        try:
            # Generate a more helpful fallback response
            topics = ["course fees", "admissions", "registration", "hostel accommodation", "campus facilities", "academic calendar", "examination schedules"]
            suggestions = random.sample(topics, 3)
            suggestions_text = ", ".join(suggestions[:-1]) + ", or " + suggestions[-1]
            
            return f"I'm not sure I understood that correctly. You can ask me about {suggestions_text}. How can I help you today?"
        except Exception as e:
            print("Database error:", str(e))
            return "There was an issue retrieving general information. Please try asking about our courses, admissions, or campus facilities."

