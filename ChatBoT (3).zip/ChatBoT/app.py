from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import LoginManager, current_user, login_required
from chat_logic import get_response
import os
import sqlite3
from models import User
from auth import auth as auth_blueprint
from dashboard import dashboard as dashboard_blueprint

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-key-please-change-in-production')
app.config['SESSION_TYPE'] = 'filesystem'

# Configure Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Please log in to access this page.'

# Database configuration - Using SQLite
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'esui_chatbot.db')

# Function to create a database connection to SQLite
def get_db_connection():
    try:
        connection = sqlite3.connect(DB_PATH)
        # Enable foreign keys
        connection.execute('PRAGMA foreign_keys = ON')
        # Return dictionary-like rows
        connection.row_factory = sqlite3.Row
        return connection
    except Exception as e:
        print("Database Connection Error:", e)
        return None

# Make the database connection available to the app
@app.before_request
def before_request():
    app.get_db_connection = get_db_connection

@login_manager.user_loader
def load_user(user_id):
    connection = get_db_connection()
    if connection:
        try:
            from auth import get_user_by_id
            return get_user_by_id(user_id, connection)
        finally:
            connection.close()
    return None

# Register blueprints
app.register_blueprint(auth_blueprint, url_prefix='/auth')
app.register_blueprint(dashboard_blueprint, url_prefix='/dashboard')

# Home route displays landing page for unauthenticated users or redirects to dashboard for authenticated users
@app.route("/")
def home():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.home'))
    return render_template('index.html')

# Original chatbot route - now protected and moved to dashboard blueprint
@app.route("/get")
@login_required
def get_bot_response():
    return redirect(url_for('dashboard.get_bot_response'))

# Create the initial database tables if they don't exist
def init_db():
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            
            # Drop existing tables to ensure schema compatibility
            cursor.execute('DROP TABLE IF EXISTS users')
            
            # Create users table with proper schema
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                student_id TEXT NULL,
                name TEXT NULL,
                is_admin BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            ''')
            
            # Create default admin user if no users exist
            cursor.execute('SELECT COUNT(*) FROM users')
            if cursor.fetchone()[0] == 0:
                from werkzeug.security import generate_password_hash
                admin_username = 'admin'
                admin_email = 'admin@esui.edu'
                admin_password = 'admin123'
                admin_name = 'System Administrator'
                
                # Hash the password
                hashed_password = generate_password_hash(admin_password)
                
                # Insert the admin user
                cursor.execute(
                    'INSERT INTO users (username, email, password_hash, name, is_admin) VALUES (?, ?, ?, ?, ?)',
                    (admin_username, admin_email, hashed_password, admin_name, True)
                )
                print('Default admin user created: Username: admin, Password: admin123')
            
            # Sample data for testing the chatbot
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS course_fees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                course_name TEXT NOT NULL,
                fee_local INTEGER NOT NULL,
                fee_foreign INTEGER NOT NULL
            )
            ''')
            
            # Insert some sample course data if the table is empty
            cursor.execute('SELECT COUNT(*) FROM course_fees')
            if cursor.fetchone()[0] == 0:
                sample_courses = [
                    ('Computer Science', 150000, 3000),
                    ('Electrical Engineering', 160000, 3200),
                    ('Business Administration', 140000, 2800),
                    ('Medicine', 200000, 4500)
                ]
                cursor.executemany('INSERT INTO course_fees (course_name, fee_local, fee_foreign) VALUES (?, ?, ?)', sample_courses)
            
            connection.commit()
            print('Database tables created successfully')
        except Exception as e:
            print(f'Error initializing database: {e}')
        finally:
            connection.close()

# Run the server
if __name__ == "__main__":
    init_db()  # Initialize database tables
    app.run(debug=True)
