from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin):
    def __init__(self, id, username, email, password_hash, student_id=None, name=None, is_admin=False):
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.student_id = student_id
        self.name = name
        self.is_admin = bool(is_admin)
    
    @staticmethod
    def create_user(username, email, password, student_id=None, name=None, is_admin=False):
        """Create a new user with hashed password"""
        password_hash = generate_password_hash(password)
        return {
            'username': username,
            'email': email,
            'password_hash': password_hash,
            'student_id': student_id,
            'name': name,
            'is_admin': is_admin
        }
    
    @staticmethod
    def check_password(password_hash, password):
        """Check if the provided password matches the hash"""
        return check_password_hash(password_hash, password)
